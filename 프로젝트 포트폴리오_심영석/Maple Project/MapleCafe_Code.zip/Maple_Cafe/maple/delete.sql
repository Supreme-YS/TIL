/*데이터 삭제*/
DELETE FROM m_orderdetail ; 
DELETE FROM m_order ;
DELETE FROM m_info ; 
DELETE FROM m_menu  ;
DELETE FROM m_staff ; 
DELETE FROM m_user ; 


