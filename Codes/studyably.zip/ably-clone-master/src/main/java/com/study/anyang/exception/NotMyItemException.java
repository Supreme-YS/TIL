package com.study.anyang.exception;

public class NotMyItemException extends Exception {

    public NotMyItemException(String msg){
        super(msg);
    }

}
