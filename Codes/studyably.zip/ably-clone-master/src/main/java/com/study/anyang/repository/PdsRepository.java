package com.study.anyang.repository;

import com.study.anyang.domain.Pds;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PdsRepository extends JpaRepository<Pds, Long> {
	
}
