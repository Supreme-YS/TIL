package com.study.anyang.exception;

public class NotEnoughCoinException extends Exception {

    public NotEnoughCoinException(String msg){
        super(msg);
    }

}
