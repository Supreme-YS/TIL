package com.studyolle.modules.notification;

public enum NotificationType {

    STUDY_CREATED, STUDY_UPDATED, EVENT_ENROLLMENT;

}
