package com.studyolle.modules.tag;

import lombok.Data;

@Data
public class TagForm {

    private String tagTitle;

}
