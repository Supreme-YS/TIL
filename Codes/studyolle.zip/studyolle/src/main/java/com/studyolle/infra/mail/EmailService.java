package com.studyolle.infra.mail;

public interface EmailService {

    void sendEmail(EmailMessage emailMessage);
}
